%%% These files allow to estimate the local projections in the terms of Jorda (2005) to the Monetary Policy Shock
%%% of Jarocinski and Karadi (2020)

%%% Acknowledgements: These codes were built, in part, thanks to the training
%%% and material provided in past editions of the BSE Macroeconometrics Summer School taught by Professors Luca
%%% Gambetti and Nicol� Maffei-Faccioli. In particular, funtions LP and lagmaker
%%% were retrieved from the summer school materials without making any relevant changes. 

set(0,'defaultAxesFontName', 'Times');
set(0,'defaultAxesLineStyleOrder','-|--|:', 'defaultLineLineWidth',1.5)

%% Load the data and set the empirical specification:

clear; close all; clc; 

%Select dataset in levels or diff for the corresponding data span

load 'Business Asymmetry - Quarterly - 1990-2016.mat'

%%%%%%%Data in log-level

%Markup estimates

Mu_CD=(log(Mu_cd(:,1)))*100;
Mu_CES_KVU=Mu_ces_oh_yk_ums(:,1)*100;
Mu_CES_KVU_OH=Mu_ces_yk_ums(:,1)*100;
MSReclag=[MSRec,lagmatrix(MSRec,1:2)];
MSExplag=[MSExp,lagmatrix(MSExp,1:2)];
MSNeglag=[MSNeg,lagmatrix(MSNeg,1:1)];
MSPoslag=[MSPos,lagmatrix(MSPos,1:1)];

%Data span

dates=1990:0.25:2016.75;

figure
subplot(2,1,1)
plot(dates,MSRec,'LineWidth',2.5), axis('tight'), grid on;
ylabel('MSPos, R&R')
xlabel('Date')
set(gca,'FontSize',16)

subplot(2,1,2)
autocorr(MSNeg) %Autocorrelation function
set(gca,'FontSize',16)

% Set up: 

hor=12; % horizon of the IRFs
c=1; % includes a constant
lags=1; % number of lags of the dependent variable
USRate_1=lagmatrix(USRate,1:2); % number of lags of the USRate

% Add controls
controls=[]; 
controls=[USRate_1 IShock D_2008 TT MSNeglag];
numcontrols=size(controls,2);

%Select variables for which to estimate the IRFs

y=[Mu_CD Mu_CES_KVU Mu_CES_KVU_OH];

%Select the lags for the shock

%Note that MSExp and MSRec are the positive MPShocks in expansions and
%recessions. MSPos is the non-business cycle dependent tightening shock

%MSRec=[MSRec,lagmatrix(MSRec,1:2)];
%MSExp=[MSExp,lagmatrix(MSExp,1:2)];
MSPos=[MSPos,lagmatrix(MSPos,1:1)];



%Set up vectors for the IRFs and the standard errors to compute the bands:

bands_beta=zeros(hor,size(y,2)); % standard errors for the bands
beta=zeros(hor,size(y,2)); % OLS estimate of beta_{0}^{h}

for i=1:size(y,2) 
    
[lp,bands]=LP(y(:,i),lags,controls,MSPos,hor,c);

bands_beta(:,i)=bands(c+lags+numcontrols+1,:)';
beta(:,i)=lp(c+lags+numcontrols+1,:)';

end

%Figure setup

figure
colorBNDS1=[0.7 0.7 0.7];
colorBNDS2=[0.5 0.5 0.5];
names={'Mu_CD', 'Mu_CES_KVU', 'Mu_CES_KVU_OH'};
HighH1=beta+1*bands_beta;
LowH1=beta-1*bands_beta;
HighH2=beta+1.65*bands_beta;
LowH2=beta-1.65*bands_beta;

for j=1:size(beta,2)
    subplot(size(beta,2),1,j)
    fill([0:hor-1 fliplr(0:hor-1)]' ,[(HighH2(1:end,j)) ; flipud((LowH2(1:end,j)))],...
        colorBNDS2,'EdgeColor','None'); hold on;
    fill([0:hor-1 fliplr(0:hor-1)]' ,[(HighH1(1:end,j)) ; flipud((LowH1(1:end,j)))],...
        colorBNDS1,'EdgeColor','None'); hold on;
    plot(0:hor-1,(LowH1(1:end,j)),'LineWidth',1,'Color','k'); hold on;
    plot(0:hor-1,(LowH2(1:end,j)),'LineWidth',1,'Color','k'); hold on;
    plot(0:hor-1,(beta(1:end,j)),'LineWidth',3.5,'Color','k'); hold on;
    plot(0:hor-1,(HighH1(1:end,j)),'LineWidth',1,'Color','k'); hold on;
    plot(0:hor-1,(HighH2(1:end,j)),'LineWidth',1,'Color','k'); hold on;
    if j==1
        title('MP Shock in Recessions - US','FontWeight','bold');
    end
     ylabel(names(j))
    line(get(gca,'Xlim'),[0 0],'Color',[1 0 0],'LineStyle','-'); hold off;
    xlim([0 length(beta(1:end,:))-1]);
    set(gca,'FontSize',18)
end
