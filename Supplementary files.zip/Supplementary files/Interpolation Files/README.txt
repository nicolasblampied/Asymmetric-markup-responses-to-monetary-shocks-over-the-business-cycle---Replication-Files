These files are retrieved from Jarocinski and Karadi (2020) and are edited in order to perform the direct interpolation of the series of interest.

Real GDP and the baseline measure of the markup (Mu_CD) are interpolated by running 'Main_US_Data'.

In order to interpolate other series, data must be updated in the excel file 'Interpolate_US_GDP&Mu_CD'. 

In this latter file, the tab 'Quarterly' must include the series to interpolate while the tab 'monthly' includes those that serve as input.

Please see Jarocinski and Karadi (2020) for further details on this methodology.