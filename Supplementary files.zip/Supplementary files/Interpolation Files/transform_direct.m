function [Y, X, names]=transform_direct(Qdata, Mdata, VoA, Qtxt, Mtxt)
%'transform' transforms given data to the specific variables needed for KF interpolations
%The function of 'transform'is specific - given new data, it should be
%revised as it generally contains commandse specific to each
%quarterly/monthly observation which cannot be incorporated into loops
Y=Qdata; %no change i ndependent variables
X=[]; %build up X - matrix of vectors of regression variables
names=[];
%% First Indicator Real GDP

Index=1;

 xreg1=(Mdata(:,1+sum(VoA(1:Index))));
 xreg2=(Mdata(:,(1+sum(VoA(1:Index))+1)));
 X=[X, xreg1 xreg2];

names=[names, 'IP ' ' Unem'];

%% Second Indicator - GDP Deflator
Index=2;

xreg1 = (Mdata(:,1+sum(VoA(1:Index)))); 
xreg2 = (Mdata(:,(1+sum(VoA(1:Index))+1)));
X=[X, xreg1 xreg2];

names=[names, ' CPI' ' PPI'];

%we drop trimming x vectors and will follow the order of precedence. This
%will be set up by order of elements in X: the first is least important,
%while the last one the most (i.e. it takes precedence over all other
%elements)

%% Quarterly Series

Y=[];

%%
Y=Qdata;

end
